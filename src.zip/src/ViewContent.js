import React from 'react'

const ViewContent = ({items,handleChecked,handleDelete,length}) => {
  return (

    
    <div className='view-page'>

      {(length !== 0) ? (
      <ul className='view-content'>

        {items.map((item)=>(
          <li key={item.id}>
         
          <p>Username: {item.name}</p>
          <p>Today work: {item.todaywork}</p>
          <p>Duration: {item.Duration}</p>
          <input type='checkbox' checked={item.checked}
           onChange={()=>handleChecked(item.id)} />
          <label> Completed</label>
          <h5>Status: {item.checked ? "Completed" : "not completed"}</h5>
          <button type='submit' onClick={()=>handleDelete(item.id)}>Delete</button>
        </li>
      ))}
        
      </ul>
      ) : <p className='fetch-error'> Your list is empty</p>}
    </div>
  )
}

export default ViewContent