
import AddItems from './AddItems';
import './App.css';
import Header from './Header';
import SearchItems from './SearchItems';
import ViewContent from './ViewContent';
import Footer from './Footer'
import { useEffect, useState } from 'react';
import ApiRequest from './ApiRequest';


function App() {

  const API='http://localhost:3500/myItem'
  const [items,setItems] =useState([])
  const [newUserName,setnewUserName]=useState('')
  const [newTodayWork,setnewTodayWork]=useState('')
  const [duration,setDuration]=useState('')
  const [fetchError, setFetchError]=useState(null)
  const [isLoading, setIsLoading]=useState(true)

  useEffect(()=>{
    const fetchItems= async() => {
      try{
        const response= await fetch(API)
       
        if(!response.ok) throw Error("Data not received")
        const listItems= await response.json();
        setItems(listItems)
        
        setFetchError(null)
      }
      catch(err){
        setFetchError(err.message)
        
      }
      finally{
        setIsLoading(false);
      }
    }

    setTimeout(()=>{
      (async() => await fetchItems())()
    },1000)
    
  },[])



 

  
  
  const addItems=async (name,todaywork,Duration) =>{
    const id=items.length ? items[items.length -1].id+1 :1;
    
    const newItems={id,name,todaywork,Duration,checked:false}
    const listItems=[...items,newItems]
    setItems(listItems)
    
    const addItems={
      method:'POST',
      Header:{
        'Content-Type':'application/json'
      },
      body:JSON.stringify(newItems)
    }
    const result=await ApiRequest(API,addItems)
    if(result) setFetchError(result)
  }

  


  const handleSubmit=(e) =>{
    e.preventDefault();
    addItems(newUserName,newTodayWork,duration)
    setDuration('')
    setnewTodayWork('')
    setnewUserName('')
  }


  const handleChecked= async (id) =>{
    const listItem= items.map((item)=>
      item.id === id ? {...item,checked:!item.checked}: item
    )
    setItems(listItem)

    const myItem=listItem.filter((item) => item.id===id)
    const updateOptions={
      method: 'PATCH',
      
      headers: {
        'Content-Type':'application/json'
      },
      body: JSON.stringify({checked:myItem[0].checked})
    }
    const reqUrl=`${API}/${id}`
    const result= await ApiRequest(reqUrl,updateOptions)
    if(result) setFetchError(result)


  }


  const handleDelete=async(id)=>{
    const filterItems= (items.filter((items)=> items.id !== id))
    setItems(filterItems);
    const updateOptions={method:'DELETE'}
    const reqUrl=`${API}/${id}`;
    const result= await ApiRequest(reqUrl,updateOptions)
    if(result) setFetchError(result)
    }
    
    const [search,setSearch]=useState('')
    

  


 

  
  

  return (
    <div>
      <Header />
      <AddItems 
        newUserName={newUserName}
        newTodayWork={newTodayWork}
        duration={duration}
        setnewUserName={setnewUserName}
        setnewTodayWork={setnewTodayWork}
        setDuration={setDuration}
        handleSubmit={handleSubmit}
      />
      <SearchItems 
        search={search}
        setSearch={setSearch}
        

      />
      
        {isLoading && <p className='fetch-error'>Loading data...</p>}
        {fetchError && <p className='fetch-error'>Error: {fetchError}</p>}

        { !isLoading && !fetchError &&
          <ViewContent 
          items={items.filter(item => item.name && item.name.toLocaleLowerCase().includes(search.toLocaleLowerCase()))}
           
            handleChecked={handleChecked}
            handleDelete={handleDelete}
            length={items.length}
          />
        }
      
      <Footer />
      
    </div>
  );
}

export default App;
