import React from 'react'
import { useRef } from 'react'

const AddItems = ({newUserName,newTodayWork,duration,setnewUserName,setnewTodayWork,setDuration,handleSubmit}) => {
    const input=useRef()
  return (
    <div>
        <form className='add-items' onSubmit={handleSubmit}>
        <input 
                autoFocus
                required
                ref={input}
                placeholder='Add your name'
                type='text'
                value={newUserName}
                onChange={(e)=> setnewUserName(e.target.value)}

            />
            <input 
                autoFocus
                required
               
                placeholder='Add today work'
                type='text'
                value={newTodayWork}
                onChange={(e)=> setnewTodayWork(e.target.value)}
            />
           <input 
                autoFocus
                required
                placeholder='Duration'
                
                type='text'
                value={duration}
                onChange={(e)=> setDuration(e.target.value)}
            />
            <button type='submit'
             onClick={()=>input.current.focus()}
            >ADD</button>

        </form>
    </div>
  )
}

export default AddItems