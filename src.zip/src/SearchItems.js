import React from 'react'

const SearchItems = ({search,setSearch}) => {
  return (
    <div className='search'>

        <form  onSubmit={(e)=>e.preventDefault()}>
          <input type="search" 
            placeholder='search user'
            required
            value={search}
            onChange={(e) =>{setSearch(e.target.value) 
              }}
            

          />
         
        </form>

    </div>
  )
}

export default SearchItems