import React from 'react'

const Header = () => {
  return (
    <div className='header'>
        <h4 id='header-name'>TO DO LIST</h4>

    </div>
  )
}

export default Header